//import React from 'react';
import axios from 'axios'; 
import ProblemaReducer from '../redux/reducers/ProblemaReducer';


const listar = (pessoaId) => {
    return axios.get( 'http://localhost:8080/problema?pessoaId='+pessoaId);
}

const buscarPeloId = (id) => {
    return axios.get( 'http://localhost:8080/problema/'+id);
}

const salvar = (problema) => {
    if(endereco.id == undefined){
        return axios.post('http://localhost:8080/problema/',problema)
    } 
    else {
        return axios.put('http://localhost:8080/problema/'+Problema.id,problema)
    }
}

const excluir = (id) => {
    return axios.delete( 'http://localhost:8080/pessoas/'+id);
}

export default {
    listar,
    buscarPeloId,
    salvar,
    excluir
}

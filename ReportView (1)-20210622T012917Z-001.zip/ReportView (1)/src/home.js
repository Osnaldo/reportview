function Home(){
    return(
        <div>
            <h1>Tela Inicial</h1>
        </div>
    );
}

export default Home;

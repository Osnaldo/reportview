import ProblemaService from "../../service/ProblemaService";

//padronizar o nome das actions
export const ENDERECO_ACTIONS = {
    LISTAR: "PROBLEMA_LISTAR",
    BUSCAR: "PROBLEMA_BUSCAR",
    SALVAR: "PROBLEMA_SALVAR",
    EXCLUIR: "PROBLEMA_EXCLUIR",
}

export function listarProblema(pessoaId) {

    return function (callback) {
        ProblemaService.listar(pessoaId)
        .then(response => {
            callback({
                type: PROBLEMA_ACTIONS.LISTAR,
                content:response.data
            })
        })
        .cacth(error => { console.log("ERROR = ", error)})
    }
}
import {PROBLEMA_ACTIONS} from "../actions/ProblemasAction";

const enderecoState = {
    enderecoLista: [],
    enderecoItem: {}
}

export default function ProblemaReducer(state = ProblemaState, callback){

    switch(callback.type){

        case PROBLEMA_ACTIONS.LISTAR:
            return {
                ...state,
                ProblemaLista: callback.content
            }


        default:
            return state;
    }

}
